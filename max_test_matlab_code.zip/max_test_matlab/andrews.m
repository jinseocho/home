

function[bb]= andrews(uind)
   nn = size(uind,1);
   ll = floor(1*nn^(1/5)-1);
   bb = uind'*uind/nn;
   ii = 1;
  while ii<(ll+1)
    xx = ii/(1+ll);
    ww = (sin(6*pi*xx/5)/(6*pi*xx/5)-cos(6*pi*xx/5))*(25/(12*pi^2*xx^2));
    bb = bb + ww*(uind((ii+1):nn,:)'*uind(1:(nn-ii),:) + uind(1:(nn-ii),:)'*uind((ii+1):nn,:))/(nn-ii);
    ii = ii + 1;
  end
end