
function [test] = pyeqp(dep,ind,itr,idx,hhh)
   
  nnn = size(dep,1);
  bet = (ind'*ind)\ind'*dep;
  uhat = dep - ind*bet;
  sig0 = uhat'*uhat/nnn;
  uind = uhat.*ind;
  
  ahat = ind'*ind/nnn;
  bhat0 = sig0*ahat;
  bhat1 = uind'*uind/nnn;
  bhat2 = andrews(uind);
  
  dd1 = bhat0\bhat1;
  dd2 = bhat2\bhat1;
  
  tst1 = pytest(dd1,nnn);
  tst2 = pytest(dd2,nnn);
  
  tst = zeros(1,2);
  pp = zeros(1,2);
  tst(1) = tst1;
  tst(2) = tst2;
  
  tss1 = pyeq1(uhat, ind, itr,idx);
  tss2 = pyeq2(uhat, ind, itr,hhh);
  
  pp(1) = mean((tss1 > tst1))*100;
  pp(2) = mean((tss2 > tst2))*100;
  
  test = [tst1,tst2,pp];
end
