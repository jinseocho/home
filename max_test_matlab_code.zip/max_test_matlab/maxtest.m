

% ********************************************************************************* 2020.2.13
% The following Matlab program illustates how to compute the two maximu test statistics in Huo and Cho (2020) 
% # and their p-values that test the following hypotheses:
% 
% # H0 versus H1    and     G0 versus G1,
% # 
% # respectively, where
% # 
% # H0: Covariance matrix is computed by error term that is conditionally homoskedastic and
% # serially uncorrelated;
% # 
% # H1: Covariance matrix is computed by error term that may be conditionally heteroskedastic
% # or serially correlated;
% # 
% # G0: Covariance matrix is computed by error term that is conditionally heteroskedastic but
% # serially uncorrelated; and
% # 
% # G1: Covariance matrix is computed by error term that is conditionally heteroskedastic but
% # serially uncorrelated.
% # 
% # Here, we assumed a linear model for the conditional mean equation to test the above 
% # hypotheses, and the unknown parameters are estimated by the OLS estimation. Three 
% # covariance matrix estimators are required to test H0 vs H1 and G0 vs. G1: the first 
% # covariance matrix estimator is obtained by assuming conditional homoskedasticity; the 
% # second covariance matrix estimator is obtained by the HC covariance matrix estimator 
% # (White 1980); and the final covariance matrix estimator is estimated by the HAC covariance 
% # matrix estimator using Andrews's (1991) kernel. 
% #
% # In order to display the same results from different programs (Gauss, R, and Matlab),
% # we use the data generated from Matlab into Gauss program and R program.  
% # The data set is saved as "data_gen.txt" 
% # 
% # Jan. 28, 2020.
% # Lijuan and Jin Seo Cho

clear;

rseed0 = 2020;
rand('seed',rseed0);
randn('seed',rseed0);


% generating an illustrative data set
nnn = 200;
xxx = [ones(nnn,1),randn(nnn,1),randn(nnn,1)];
uuu = randn(nnn,1);
par = ones(3,1);
yyy = xxx*par + uuu;

% inputs for computing the max tests
ind = xxx;   % regressor
dep = yyy;   % dependent variable
its = 10000; % number of bootstrap replications

idx = floor(rand(nnn,its)*nnn + 1);
hhh = 2*floor(randn(nnn,its)>0)-1;
dat_gen = [ind,dep,idx,hhh];   % data_gen will be used for R and Gauss
% please make sure that matlab,R,and Gauss have the same nnn, and same its.
dlmwrite('data_gen.txt',dat_gen,"\t");

results = pyeqp(dep,ind,its,idx,hhh);

fprintf('testing covariance matrix\n');
fprintf('**************************************************\n');
fprintf('testing results: H0 vs. H1:\n maxtest = %5.2f; p-value = %2.2f%% \n',results(1),results(3));
fprintf('**************************************************\n');
fprintf('testing results: G0 vs. G1:\n maxtest = %5.2f; p-value = %2.2f%% \n',results(2),results(4));
fprintf('**************************************************\n');