  
function [mx] = pytest(hdd,nn)
  dd = size(hdd,1);
  tauh = sum(diag(hdd))/dd - 1; etah = dd/sum(diag(inv(hdd))) -1; delh = (det(hdd))^(1/dd) - 1;
  gamh = delh - etah; zeth = tauh - delh;
  tdd  = inv(hdd);
  taut = sum(diag(tdd))/dd - 1; etat = dd/sum(diag(inv(tdd))) -1; delt = (det(tdd))^(1/dd) - 1;
  gamt = delt - etat; zett = taut - delt;
  mss = zeros(12,1);   
  mss(1) = nn*dd*(tauh^2 + 2*zeth)/2; mss(2) = nn*dd*(delh^2 + 2*zeth)/2; mss(3) = nn*dd*(delh^2 + 2*gamh)/2;
  mss(4) = nn*dd*(etah^2 + 2*gamh)/2; mss(5) = nn*dd*(tauh^2 + 2*gamh)/2; mss(6) = nn*dd*(etah^2 + 2*zeth)/2;
  mss(7) = nn*dd*(taut^2 + 2*zett)/2; mss(8) = nn*dd*(delt^2 + 2*zett)/2; mss(9) = nn*dd*(delt^2 + 2*gamt)/2;
  mss(10)= nn*dd*(etat^2 + 2*gamt)/2; mss(11)= nn*dd*(taut^2 + 2*gamt)/2; mss(12)= nn*dd*(etat^2 + 2*zett)/2;
  mx = max(mss);  
end
