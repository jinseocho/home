function [tss] = pyeq1(uhat,ind,itr,idx)

  nn = size(uhat,1);
  tss= zeros(itr,1);
  ii = 1;
  while ii < (itr+1)
    
    iuhat = uhat(idx(:,ii));
    uind = iuhat.*ind;
    sig = iuhat'*iuhat/nn;
    dd0 = sig*(ind'*ind)/nn;
    dd1 = uind'*uind/nn;
    hdd = dd0\dd1;
    tss(ii,1) = pytest(hdd, nn);
    ii = ii + 1;
  end
end
