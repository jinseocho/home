
function [tss] = pyeq2(uhat,ind,itr,hhh)

  nn = size(uhat,1);
  tss= zeros(itr,1);
  ii = 1;
  while ii<(itr+1)

    iuhat = uhat.*hhh(:,ii);
    uind  = iuhat.*ind;
    dd1 = uind'*uind/nn; 
    dd2 = andrews(uind);
    hdd = dd1\dd2;
    tss(ii,1) = pytest(hdd,nn);
    ii = ii+1;
  end
end