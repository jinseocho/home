The following GAUSS program file and GAUSS procedure files are provide to compute the max test statistics in Huo and Cho (2020).

andrews.prc
powmat.prc
pyeq1.prc
pyeq2.prc
pyeqp.prc
pytest.prc, and
maxtest.prg

To use this program code, the reader is expected to modify "maxtest.prg" after saving all above files into the same folder and 
changing the working directory to the folder containing the above files.

The program "maxtest.prg" contains an illustrative example formed by an randomly generated data set. The reader can replace 
the randomly generated data set with his/hers.

Two max tests are provided to test H0 vs. H1; and G0 vs. G1, where

    H0: Covariance matrix is computed by error term that is conditionally homoskedastic and serially uncorrelated;
    H1: Covariance matrix is computed by error term that may be conditionally heteroskedastic or serially correlated;
    G0: Covariance matrix is computed by error term that is conditionally heteroskedastic but serially uncorrelated; and
    G1: Covariance matrix is computed by error term that is conditionally heteroskedastic but serially uncorrelated.

Here, the covariance matrix is the covariance matrix of the OLS estimator.

The format of the command to compute the max tests and their p-values is as follows:

    {tst, pp} = pyeqp(dep, ind, its)

where 

    "dep" denotes the dependent observations (n by 1);
    "ind" denotes the regressors (n by k); and 
    "its" denotes the bootstrap replication numbers. 

Here, "n" and "k" mean the sample size and the number of regressors, respectively.

Jan. 28, 2018
Lijuan Huo and Jin Seo Cho
