filename1 = 'dataset.dat';   % The only line to change

filename2 = 'cvs_10krep_sp2.txt';
[data, delimiterOut] = importdata(filename1);
[cv, delimiterOut] = importdata(filename2);

nnn = rows(data);
pp = seqa(1/nnn,1/nnn,nnn);
fff = zeros(nnn,4);
iii = 2;
while iii <= nnn-1;
    zzz3 = grgbase(nnn,data,pp(iii,1));
    intr3 = sum(abs(zzz3))/100;
    fff(iii,1) = intr3;
    fff(iii,2) = max(abs(zzz3));
    iii = iii + 1;
end;

etas = max(fff(:,2));
tetas= sumc(fff(:,1))/nnn;
petas = zeros(rows(cv),1);
pteta = zeros(rows(cv),1);

iii = 1;
while iii <= rows(cv);
    if cv(iii,2) > etas;
        petas(iii,1) = 1;
    else;
        petas(iii,1) = 0;
    end;
    if cv(iii,3) > tetas;
        pteta(iii,1) = 1;
    else;
        pteta(iii,1) = 0;
    end;
    iii = iii + 1;
end;

pvetas = mean(petas);
pvteta = mean(pteta);

disp('sup-norm based GR test');
disp(etas);
disp('sup-norm based p-value');
disp(pvetas);
disp('L1-norm based GR test');
disp(tetas);
disp('L1-norm based p-value');
disp(pvteta);
