function x=delif(y,cond);
%indexcat Select values of x for which cond is false
x=x(cond==0);
return;
