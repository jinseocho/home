function[zxc] = grgbase(ddd,eee,p)
grd = 0.01;
sss = seqa(-0.5, 0.01, 101);
lll = quantile(eee,p);
zxc = zeros(101,1);
nn = rows(eee);
ww = zeros(nn,2);

iii = 1;
while iii <= nn;
    if (eee(iii,1) <= lll);
        ww(iii,1) = 0;
    else;
        ww(iii,1) = 1;
    end;
    iii = iii + 1;
end;
ww(:,2) = seqa(1,1,nn);

wt = selif(ww(:,2), ww(:,1) == 0);

if (rows(wt) > 1);
    q = rows(wt) -1;
    zz= wt(2:rows(wt),1) - wt(1:q,1);
    mm= rows(zz);

    iii=1;
    while iii <= 101;
        as = zeros(mm,1);
        jjj = 1;
        while jjj <= rows(zz);
            as(jjj,1) = sss(iii,1).^zz(jjj,1);
            jjj = jjj + 1;
        end;        
        yd = sum(as(:,1)) - mm*sss(iii,1)*p/(1-(1-p)*sss(iii,1));
        zxc(iii,1) = yd/sqrt(nn);
        iii = iii + 1;
    end;
else;
    zxc = zeros(101,1);
end;    

return;