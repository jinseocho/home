SWELM <- function(dep,ind1,ind2){

  # prototype function for sequential WELM test 
  # dep: dependent variable
  # ind1: independent varialbe with possible high degrees
  # ind2: other independent variables
  # output: p-values of test for 1st, 2nd, 3rd, 4th, and 5th degree function.



nnn = length(dep)

mmm = 10000

kkk = 1   # replication times for simulation, example:1000,5000,100000

www_1 = www_2 = www_3 = www_4 = www_5 = matrix(0,kkk,5)

xxx = ind1
  
  del = runif(mmm,0,2)
  ppp = matrix(0,nnn,1)        
  for (jjj in 1:nnn){
    ppp[jjj,1] = mean(exp(xxx[jjj]*del))  #Phi(delta)=exp(delta*Y)
  }
 
  for (iii in 1:kkk){
  ################ power = 1 ###################
  ind = cbind(1,xxx,ind2)  # power = 1
  
  beth = solve(t(ind)%*%ind)%*%t(ind)%*%dep
  uhat = dep-ind%*%beth
  
  nind = cbind(1,uhat)
  ndep = ppp
  beta = solve(t(nind)%*%nind)%*%t(nind)%*%ndep
  
  ihat = t(as.vector(uhat)*ind)%*%(as.vector(uhat)*ind)/(nnn)
  dhat = t(ind)%*%ind/(nnn)
  sgh2 = t(uhat)%*%uhat/(nnn)
  kk3  = mean(uhat^2*ppp^2)
  bkk = colMeans(as.matrix(as.vector(ppp)*ind))
  rho = colMeans(as.matrix(as.vector(uhat^2*ppp)*ind))
  vsgh = (kk3-2*t(bkk)%*%solve(dhat)%*%rho+t(bkk)%*%solve(dhat)%*%ihat%*%solve(dhat)%*%bkk)/sgh2^2
  
  welm = nnn*beta[2,1]^2/vsgh
  
  www_1[iii,1] = iii/kkk
  www_1[iii,2] = welm
  www_1[iii,3] = pchisq(welm,1)
  
  
  
  ################ power = 2 ###################
  
  
  ind = cbind(1,xxx,xxx^2,ind2)  # power = 2
  
  beth = solve(t(ind)%*%ind)%*%t(ind)%*%dep
  uhat = dep-ind%*%beth
  
  nind = cbind(1,uhat)
  ndep = ppp
  beta = solve(t(nind)%*%nind)%*%t(nind)%*%ndep
  
  ihat = t(as.vector(uhat)*ind)%*%(as.vector(uhat)*ind)/nnn
  dhat = t(ind)%*%ind/nnn
  sgh2 = t(uhat)%*%uhat/nnn
  kk3  = mean(uhat^2*ppp^2)
  bkk = colMeans(as.matrix(as.vector(ppp)*ind))
  rho = colMeans(as.matrix(as.vector(uhat^2*ppp)*ind))
  vsgh = (kk3-2*t(bkk)%*%solve(dhat)%*%rho+t(bkk)%*%solve(dhat)%*%ihat%*%solve(dhat)%*%bkk)/sgh2^2
  
  welm = nnn*beta[2,1]^2/vsgh
  
  www_2[iii,1] = iii/kkk
  www_2[iii,2] = welm
  www_2[iii,3] = pchisq(welm,1)
  
  print(cbind(beta[2],welm,pchisq(welm,1)))
  ############## power = 3 ##############
  
  ind = cbind(1,xxx,xxx^2,xxx^3,ind2)  
  
  beth = solve(t(ind)%*%ind)%*%t(ind)%*%dep
  uhat = dep-ind%*%beth
  
  nind = cbind(1,uhat)
  ndep = ppp
  beta = solve(t(nind)%*%nind)%*%t(nind)%*%ndep
  
  ihat = t(as.vector(uhat)*ind)%*%(as.vector(uhat)*ind)/nnn
  dhat = t(ind)%*%ind/nnn
  sgh2 = t(uhat)%*%uhat/nnn
  kk3  = mean(uhat^2*ppp^2)
  bkk = colMeans(as.matrix(as.vector(ppp)*ind))
  rho = colMeans(as.matrix(as.vector(uhat^2*ppp)*ind))
  vsgh = (kk3-2*t(bkk)%*%solve(dhat)%*%rho+t(bkk)%*%solve(dhat)%*%ihat%*%solve(dhat)%*%bkk)/sgh2^2
  
  welm = nnn*beta[2,1]^2/vsgh
  
  www_3[iii,1] = iii/kkk
  www_3[iii,2] = welm
  www_3[iii,3] = pchisq(welm,1)
  
  
  ############## power = 4 ##############
  
  ind = cbind(1,xxx,xxx^2,xxx^3,xxx^4,ind2)  
  
  beth = solve(t(ind)%*%ind)%*%t(ind)%*%dep
  uhat = dep-ind%*%beth
  
  nind = cbind(1,uhat)
  ndep = ppp
  beta = solve(t(nind)%*%nind)%*%t(nind)%*%ndep
  
  ihat = t(as.vector(uhat)*ind)%*%(as.vector(uhat)*ind)/nnn
  dhat = t(ind)%*%ind/nnn
  sgh2 = t(uhat)%*%uhat/nnn
  kk3  = mean(uhat^2*ppp^2)
  bkk = colMeans(as.matrix(as.vector(ppp)*ind))
  rho = colMeans(as.matrix(as.vector(uhat^2*ppp)*ind))
  vsgh = (kk3-2*t(bkk)%*%solve(dhat)%*%rho+t(bkk)%*%solve(dhat)%*%ihat%*%solve(dhat)%*%bkk)/sgh2^2
  
  welm = nnn*beta[2,1]^2/vsgh
  www_4[iii,1] = iii/kkk
  www_4[iii,2] = welm
  www_4[iii,3] = pchisq(welm,1)
  
  
  ############## power = 5 ##############

    ind = cbind(1,xxx,xxx^2,xxx^3,xxx^4,xxx^5,ind2)

  beth = solve(t(ind)%*%ind)%*%t(ind)%*%dep
  uhat = dep-ind%*%beth
  
  nind = cbind(1,uhat)
  ndep = ppp
  beta = solve(t(nind)%*%nind)%*%t(nind)%*%ndep
  
  ihat = t(as.vector(uhat)*ind)%*%(as.vector(uhat)*ind)/nnn
  dhat = t(ind)%*%ind/nnn
  sgh2 = t(uhat)%*%uhat/nnn
  kk3  = mean(uhat^2*ppp^2)
  bkk = colMeans(as.matrix(as.vector(ppp)*ind))
  rho = colMeans(as.matrix(as.vector(uhat^2*ppp)*ind))
  vsgh = (kk3-2*t(bkk)%*%solve(dhat)%*%rho+t(bkk)%*%solve(dhat)%*%ihat%*%solve(dhat)%*%bkk)/sgh2^2
  
  welm = nnn*beta[2,1]^2/vsgh

    www_5[iii,1] = iii/kkk
    www_5[iii,2] = welm
    www_5[iii,3] = pchisq(welm,1)


  print(iii)
  iii = iii+1}

# power = 1
www_1[,4] = sort(www_1[,3])
www_1[,5] = sort(www_1[,2])

# power = 2
www_2[,4] = sort(www_2[,3])
www_2[,5] = sort(www_2[,2])

# power = 3
www_3[,4] = sort(www_3[,3])
www_3[,5] = sort(www_3[,2])

# power = 4
www_4[,4] = sort(www_4[,3])
www_4[,5] = sort(www_4[,2])

power = 5
www_5[,4] = sort(www_5[,3])
www_5[,5] = sort(www_5[,2])


#print("there are 5 cols in matrix www: 1st is the sequence; 5th is the sorted WELM; 4th is the sorted prob.")

row1 = c(1,2,3,4,5)
row2 = round(c((1-www_1[,4]),(1-www_2[,4]),(1-www_3[,4]),(1-www_4[,4]),(1-www_5[,4])),4)

outmat = rbind(c("degree",row1),c("p-value",row2))

print(outmat)
}
