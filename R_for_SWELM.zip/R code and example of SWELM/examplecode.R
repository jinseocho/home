rm(list=ls())


source('~/SWELM.R', encoding = 'UTF-8')

dat = read.csv("exampledata.csv")  # import example data
# example data is generated from 2nd degree function

head(dat)

dep = dat[,2]   # dependent variable
ind1 = dat[,3]  # one independent variable with possible high degree(s)
ind2 = dat[,4]  # other independent variable(s) 

SWELM(dep,ind1,ind2) #p-values of tests for 1st, 2nd, 3rd, 4th, and 5th degree function
